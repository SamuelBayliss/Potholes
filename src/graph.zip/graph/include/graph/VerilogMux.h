

//need to accept signals and a mux indicator

