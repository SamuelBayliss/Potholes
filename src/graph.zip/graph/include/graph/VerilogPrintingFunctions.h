/*
 *  VerilogPrintingFunctions.h
 *  VerilogLibrary
 *
 *  Created by Samuel Bayliss on 10/12/2011.
 *  Copyright 2011 Imperial College. All rights reserved.
 *
 */

#include <iostream>
#include <vector>
#include <string>

#include <iosfwd>
#include <iomanip>

const int COMMA = 1;
const int SEMICOLON = 2;
const int NEWLINE = 4;
const int NONE = 5;
const int SEMICOLON_NEWLINE = 7;
const int BRACKETS = 8;

class ModifierConstants
{

	friend class Separator;
public:
	static int GetSeparatorAlloc() { return m_Separator_nAlloc;};
	static int GetEnclosureAlloc() { return m_Enclosure_nAlloc;};
private:
	static const int m_Separator_nAlloc;
	static const int m_Enclosure_nAlloc;
};

const int ModifierConstants::m_Separator_nAlloc = std::ios_base::xalloc();
const int ModifierConstants::m_Enclosure_nAlloc = std::ios_base::xalloc();

class Separator
{
	public :
	explicit Separator(char separator) : separator(separator){}

	template<class charT, class Traits> 
		friend std::basic_ostream<charT, Traits> & operator << (std::basic_ostream<charT, Traits >&os, const Separator& s)
	{ 
		os.iword(ModifierConstants::GetSeparatorAlloc()) += s.separator;
		return os;
	}
				 
	private : 
	int separator;
};

class Enclosure
{
	public :
	explicit Enclosure(int enclosure) : enclosure(enclosure){}
	
	template<class charT, class Traits> 
	friend std::basic_ostream<charT, Traits> & operator << (std::basic_ostream<charT, Traits >&os, const Enclosure& s)
	{ 
		os.iword(ModifierConstants::GetEnclosureAlloc()) = s.enclosure;
		return os;
	}
	
	private : 
	int enclosure;
};




template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T> & list) {
	
	typename std::vector<T>::const_iterator vit = list.begin();
	
	while (vit != list.end()) {
		
		if (vit == list.begin()) {
			switch (os.iword(ModifierConstants::GetEnclosureAlloc()))
			{
				default: 
			    case BRACKETS : 
					os << '(';
					break;
				case NONE : 
					os << ' ';
					break;
			}
		}
		
		os << *vit;
		
		if (vit + 1 == list.end()) 
		{	
			switch (os.iword(ModifierConstants::GetEnclosureAlloc()))
			{
				default: 
			    case BRACKETS : 
					os << ')';
					break;
				case NONE : 
					os << ' ';
					break;
			}
		}
		else {
			switch (os.iword(ModifierConstants::GetSeparatorAlloc()))
			{
				default: 

				case COMMA :
				  os << ",";
					break;
				case SEMICOLON :
					os << ";";
					break;
			        case NEWLINE :
					os << "\n";
					break;
		                case SEMICOLON_NEWLINE :
					os << ";\n";
					break;
			}
		}
		vit++;

	}
	return os;
}
// specialize for Symbol list (should print semicolon separated declarations)

// os << separate(',');
// os << enclose('(',')');

// specialize for Symbol : Symbol pairs (should print semicolon separated instantiations in a bracket);
