/*
 *  VerilogExpression.h
 *  VerilogLibrary
 *
 *  Created by Samuel Bayliss on 29/11/2011.
 *  Copyright 2011 Imperial College. All rights reserved.
 *
 */

#include "VerilogContext.h"
#include "VerilogSymbol.h"

#include <vector>
#include <iostream>
class VerilogGraphNode 
{
 private:

 public: 
  VerilogGraphActor * owner;
	
	VerilogSymbolDirection::Direction direction;
	VerilogGraphNode * next;
        VerilogGraphNode * back;
	
public:
	// inserts a node into a Graph Actors
	static VerilogGraphNode * insert(VerilogGraphActor * owner, VerilogGraphNode * node, VerilogSymbolDirection::Direction dir, VerilogGraphNode * edge);
	// builds a list of all the connected graph actors. 
	static void gather(VerilogGraphNode *, VerilogGraphActor *, std::vector<VerilogGraphActor *>&);
	void print(std::ostream& os) const;
};



class VerilogExpression : public VerilogGraphActor
{
private:
	VerilogExpression();
public:
	VerilogExpression(VerilogGraphActor *);
	virtual std::string print() const;
	VerilogGraphNode * getOutput() { return getOutput(this);};
	static VerilogGraphNode * getOutput(VerilogGraphActor *);
	static void emit(std::ostream& os, VerilogSymbol vs, VerilogExpression * );
	virtual  void emit(std::ostream& os) const { os << "Hello"; };
};





class VerilogTermExpression : public VerilogExpression
{
public:
        VerilogTermExpression(VerilogConstant &  sym); // used for implicit cast to VerilogTermExpression
	VerilogTermExpression(VerilogConstant & sym, bool);
	VerilogTermExpression(VerilogSymbol &, bool);
	VerilogTermExpression(VerilogSymbol &); // used for implicit cast to VerilogTermExpression
	std::string print() const { return "VerilogTermExpression";}
	static VerilogGraphNode * getInput(const VerilogGraphActor *);
	VerilogGraphNode * getInput() const { return getInput(this);};
	void emit(std::ostream& os) const;
};

class VerilogConstantExpression : public VerilogExpression
{
	VerilogConstantExpression(int); // used for iplicit cast from constant;
public:
	std::string print() const{ return "VerilogTermExpression : ";}
};

class VerilogReduction : public VerilogExpression
{
 public : 
  typedef enum {RedPlus, RedMinus} Type;
  VerilogReduction(VerilogReduction::Type, std::vector<VerilogExpression>);
  std::string print() const { return "VerilogReduction";}
  VerilogReduction(VerilogReduction::Type, std::vector<VerilogExpression>, bool hasShadow);
  void emit(std::ostream& os) const;	
};

/*
class VerilogMuxOperations {

 public : 
  virtual std::string print() = 0;
  virtual void operator>>(VerilogTermExpression& vt) = 0;
}

class VerilogMuxPtr : public VerilogMuxOperations, Verilog{ 
 public : 
  std::string print() {
    return "Mux";
  }
  void operator>>(VerilogTermExpression& vt) { } ;
}

typedef VerilogMuxPtr VerilogMux;

class VerilogMuxActor : public VerilogMuxOperations, VerilogExpression { 

}
*/


class VerilogMux : public VerilogExpression
{
 
 public : 
  VerilogMux(VerilogTermExpression &);
  std::string print() const { return "VerilogMux";}
  VerilogMux(VerilogTermExpression &, bool hasShadow);
  void emit(std::ostream& os) const;	
  void operator>>(VerilogTermExpression&);
};

//typedef std::pair<VerilogMux, unsigned> VerilogMuxSelection;

/*void VerilogMux::
VerilogMux a

a[0] >>= aSym;
a[1] >>= bSym;
& operator >>=(T& a, const T& b);


// to achieve this

*/

class VerilogBinaryExpression : public VerilogExpression
{
public:
  typedef enum {BinPlus, BinMinus, BinMult, BinEqual} Type;
	VerilogBinaryExpression(VerilogExpression, VerilogExpression);
		std::string print() const { return "VerilogBinaryExpression";}
	VerilogBinaryExpression(VerilogExpression a, VerilogExpression b, bool hasShadow);
	void emit(std::ostream& os) const;
};

// Need to make a spectacular number of constructors. 


VerilogExpression operator*(VerilogTermExpression a, VerilogTermExpression b);
//VerilogExpression operator*(VerilogConstant a, VerilogTermExpression b);


// try out verilog 

