
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <stdexcept>
#include <cmath>
#include <vector>
#include <cassert>

#ifndef VERILOG_VALUE_HEADER
#define VERILOG_VALUE_HEADER

std::string toBinary(unsigned size, unsigned value);
std::string SignedToVerilogConstant(unsigned size, int long value);
std::string UnsignedToVerilogOneHot(unsigned size, unsigned value);
std::string UnsignedToVerilogConstant(unsigned size, unsigned long value);
#endif
