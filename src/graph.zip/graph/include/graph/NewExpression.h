
class VerilogGraphActor {
 protected : 
  VerilogGraphNode * list;
  // insert into list functionality
  // delete from list functionality
}

PointerType : shadow(NULL) {
 private : 
  VerilogGraphActor * shadow;
  
 public:
  bool valid() { 
    return (shadow != NULL);
  }

  // Copying a pointer increments the reference count of shadow
  // Assigning a pointer decrements the reference count of the default object and increments the shadow reference count
  
}


class VerilogExpressionIntf {
  virtual VerilogGraphNode * getOutput(const VerilogExpressionIntf *) = 0;
};


VerilogExpressionPtr : PointerType, VerilogExpressionIntf {
 protected:
  VerilogExpressionIntf
  VerilogGraphNode * getOutput() {
    return VerilogExpressionImpl::getOutput(getShadow());
  }

 private: 
  VerilogExpression() : shadow(NULL); // never called
  // implicit copy constructor calls base copy constructors (and therefore increments reference counts)
}

typedef VerilogExpressionPtr VerilogExpression;

VerilogExpressionImpl : VerilogExpressionIntf {

}


VerilogTermExpressionPtr : VerilogExpressionPtr, VerilogTermExpressionIntf
{ 
 VerilogTermExpression(Symbol *) : 
}

