/*
 *  VerilogLibraryPriv.h
 *  VerilogLibrary
 *
 *  Created by Samuel Bayliss on 28/11/2011.
 *  Copyright 2011 Imperial College. All rights reserved.
 *
 */

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

class VerilogLibraryPriv
{
	public:
		void HelloWorldPriv(const char *);
};

#pragma GCC visibility pop
