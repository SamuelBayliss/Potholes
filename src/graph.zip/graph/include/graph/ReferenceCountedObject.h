/*
 *  ReferenceCountedObject.h
 *  VerilogLibrary
 *
 *  Created by Samuel Bayliss on 28/11/2011.
 *  Copyright 2011 Imperial College. All rights reserved.
 *
 */

#ifndef VerilogCountedObject_H
#define VerilogCountedObject_H

class ReferenceCountedObject
{
	public: 
		unsigned refCount;
	public:	
	unsigned getRefCount() const {return refCount;};
	static void decrement(ReferenceCountedObject *);
	static void increment(ReferenceCountedObject *);
	ReferenceCountedObject(unsigned);
	virtual ~ReferenceCountedObject();
};

#endif VerilogCountedObject_H
