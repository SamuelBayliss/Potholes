/*
  Symbols have a context
 
  Symbols can be constants or variables. 
  Symbols can have varied bitwidths

 */

// Symbols have a name which is unique in the context

//typedef mpz_t VerilogValue;


#include "ReferenceCountedObject.h"



#ifndef VerilogSymbol_H
#define VerilogSymbol_H

#include "VerilogContext.h"
#include <graphviz/gvc.h>
#include <gmp.h>

class VerilogExpression;
class VerilogTermExpression;
class VerilogBinaryExpression;

class VerilogGraphNode;

#include <string>
#include <iostream>
#pragma GCC visibility push(default)

class VerilogGraphActor : public ReferenceCountedObject {
	
private :
	VerilogGraphActor(); // default constructor (generates shadow by default), private since initializion must be done by Expression or Symbol
protected:
	VerilogGraphNode * list;
	VerilogGraphActor * shadow;
	VerilogGraphActor(VerilogGraphActor *); // constructor (with optional shadow)
public:
	void print_dot_file(std::string filename) const;
	
	void createGraphNodes(const VerilogGraphNode * node, const VerilogGraphActor * root, Agraph_t * graph) const;
	VerilogGraphActor * getShadow() const  {return shadow;}
	VerilogGraphNode * getList() const { return list;}
	virtual std::string print() const {return "GraphActor";};
};


class VerilogConstant : public VerilogGraphActor
{
 private : 

  VerilogContext * vc;
  unsigned size;
  mpz_t value;
  VerilogConstant();
 protected : 
  VerilogConstant(mpz_t value, bool);
 public : 
  VerilogConstant( mpz_t value);
  VerilogConstant(VerilogConstant *);
  VerilogConstant(const VerilogConstant&);
  ~VerilogConstant();
  VerilogGraphNode * getOutput();
  //  friend void VerilogContext::insert(VerilogConstant &,  VerilogModule * );
  std::string print() const;
  void emit (std::ostream& os) const;
  static VerilogGraphNode * getOutput(VerilogGraphActor * actor);
};


class VerilogSymbol : public VerilogGraphActor
{

private : 
	std::string name;
	bool isReg;
	VerilogContext * vc;
	unsigned size;
	VerilogSymbolDirection::Direction direction;
	VerilogSymbol();
	VerilogGraphNode * getInputOutput(VerilogSymbolDirection::Direction);

protected:

	VerilogSymbol(std::string, bool, unsigned);
	VerilogSymbol(std::string, bool);
 public:
	void setReg();	
	bool isRegister() const{ return isReg;} ;
	void setSize(unsigned);
      	VerilogSymbol(std::string);
	VerilogSymbol(VerilogSymbol *);
	VerilogSymbol(const VerilogSymbol&);
	VerilogSymbol & operator=(const VerilogSymbol& vs) ;
	~VerilogSymbol();
	const std::string getName() const;
	const VerilogSymbolDirection::Direction getDirection() const;
	//VerilogSymbol * getShadow();
	static bool valid(const VerilogSymbol);
	VerilogGraphNode * getOutput();
	VerilogGraphNode * getInput();
	unsigned getSize()  const { return size;};
	std::string print_declaration() const;
	static VerilogGraphNode * getInput(VerilogGraphActor *);
	static VerilogGraphNode * getOutput(VerilogGraphActor *);

	VerilogSymbol operator=(VerilogExpression);
	bool operator<(const VerilogSymbol&) const;
	
	/*VerilogSymbol operator=(VerilogTermExpression);
	VerilogSymbol operator=(VerilogBinaryExpression);
	 */
	friend void VerilogContext::insert(VerilogSymbol &,  VerilogModule *  , VerilogSymbolDirection::Direction);
	std::string print() const;
	void emit (std::ostream& os) const;
	friend std::ostream& operator<<(std::ostream&, const VerilogSymbol &);
};

std::ostream& operator<<(std::ostream&, const VerilogSymbol &);

#pragma GCC visibility pop
#endif


/*
class BoundedSymbol : public Symbol
{
 private:
  VerilogValue size;
}

class ConstantSymbol : public BoundedSymbol;
{
 private:
  VerilogValue value;
}
*/



// Symbols are created in the default context

/* Example

Symbol A("A");
Symbol B("B");
Symbol C("Val");

C = A+B; // should create adder

C = (A == B); should create comparison

C = floor(A / C);

Division by constant gives a symbol and DivisionConstant

Specialization by floor destroys division constant and instantiates custom divider


D = ceil(A / C);

VerilogMultiplexer mux(A,B); // creates multiplexer in same context as A,B
mux.select(C);

VerilogShiftRegister sr(A,B); 
// creates additional symbol in same context as A and B
sr.enable(D)


 */

