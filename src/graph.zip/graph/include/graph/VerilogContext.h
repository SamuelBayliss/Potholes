/*
 *  VerilogContext.h
 *  VerilogLibrary
 *
 *  Created by Samuel Bayliss on 28/11/2011.
 *  Copyright 2011 Imperial College. All rights reserved.
 *
 */

#ifndef VerilogContext_H
#define VerilogContext_H

#pragma GCC visibility push(default)


class VerilogModule;
class VerilogSymbol;
class VerilogExpression;

#include <map>
#include <set>
#include <vector>
struct VerilogSymbolDirection {
  typedef enum {None = 0, Input = 1, Output = 2, Local = 4} Direction;

};

class VerilogGraphActor;
class VerilogGraphNode;
class GraphTraversal {
 public:
  virtual void visit (VerilogGraphNode *) = 0;
};

class VerilogContext
{
	public :
	typedef std::pair<VerilogSymbolDirection::Direction,  VerilogModule*> ModuleMapKey; 
		private :
	struct KeyComparison{
		bool operator()( ModuleMapKey a,  ModuleMapKey b) 
		{
			VerilogSymbolDirection::Direction adir = a.first;
			VerilogSymbolDirection::Direction bdir = b.first;
			
			if (adir == bdir)
			{ 
				return (a.second < b.second);
			}
			
			return (adir < bdir);
		}
	};
	/**
	   
	   May Add a symbol to a module, assume once a symbol is added to a module, it's direction is fixed

	 */	
 public:
	typedef std::multimap<ModuleMapKey, VerilogSymbol*, VerilogContext::KeyComparison> ModuleSymbolMap;
	typedef std::multimap<ModuleMapKey, VerilogSymbol*, VerilogContext::KeyComparison>::iterator ModuleSymbolMapIterator;
	typedef std::multimap<ModuleMapKey,  VerilogSymbol*, VerilogContext::KeyComparison>::const_iterator ModuleSymbolMapConstIterator;
	typedef std::pair<VerilogContext::ModuleSymbolMapIterator, VerilogContext::ModuleSymbolMapIterator> ModuleSymbolMapRange;
 private:	
	ModuleSymbolMap sy;
 public:
	typedef std::map< VerilogExpression *,  VerilogModule*, std::less< VerilogExpression *> > ModuleExpressionMap;
	typedef std::map< VerilogExpression *,  VerilogModule*, std::less< VerilogExpression *> >::iterator ModuleExpressionMapIterator;
	typedef std::map< VerilogExpression *,  VerilogModule*, std::less< VerilogExpression *> >::const_iterator ModuleExpressionMapConstIterator;
 private:
	ModuleExpressionMap em;
	
	std::vector<VerilogModule *> ml;
	
	static VerilogContext * pInstance;
	void Initialize();
	public : 
	static VerilogContext * getContext();
	void createContext();
	protected :
	VerilogContext(); 
	
private:
	VerilogModule * find_owner( VerilogSymbol *);
	VerilogModule * find_owner( VerilogExpression *);
	void setOwner(std::set<VerilogGraphActor *>&,  VerilogModule *);

public : 
	void clear();
	void insert( VerilogSymbol &,  VerilogModule *, VerilogSymbolDirection::Direction);
	void insert(VerilogModule *);
	VerilogSymbol lookup( std::string&,  VerilogModule* ,VerilogSymbolDirection::Direction);
	VerilogSymbolDirection::Direction lookup(const VerilogModule *, VerilogSymbol ) const; 
	VerilogModule lookup(std::string); // lookup module  
	std::set<std::pair<VerilogSymbol, VerilogExpression *> > getExpressionOutputs(const VerilogModule *);
	VerilogModule * find_unique_owner(std::set<VerilogGraphActor *>& vec);
	void connect(VerilogGraphActor *,  std::vector<VerilogGraphActor *>& actors);
	void dump(std::ostream&);
	void emit(std::ostream&);
	void dump(std::set<VerilogGraphActor *>&, std::ostream&);
	std::vector<std::string> getSymbolNames(const VerilogModule *, unsigned mask) const;
	std::vector<VerilogSymbol> getSymbols(const VerilogModule *, unsigned mask) const ;
	std::vector< VerilogModule *> getModules() const;
	void gather_domain_edges(VerilogGraphActor * e, std::vector<VerilogGraphActor *>& inputs, std::vector<VerilogGraphActor *>& outputs);
};

#pragma GCC visibility pop
#endif
