/*
 *  VerilogModule.h
 *  VerilogLibrary
 *
 *  Created by Samuel Bayliss on 28/11/2011.
 *  Copyright 2011 Imperial College. All rights reserved.
 *
 */
#ifndef VerilogModule_H
#define VerilogModule_H


class VerilogContext;
class VerilogSymbol;

#include <string>
#include <iostream>
#include <vector>
#include "VerilogSymbol.h"

// Shouldn't be a graph actor, only want the features of shadowed components
class VerilogModule : public VerilogGraphActor
{
private:  
	VerilogModule(VerilogContext * vc, std::string nm, bool);
protected:
	std::string name;
	std::vector<std::string> fragments;
	VerilogContext * vc;
public:
	VerilogModule(VerilogContext *, std::string);
	VerilogModule(VerilogContext *, VerilogModule *);
	void push_string(std::string str) {
	VerilogModule * module = dynamic_cast<VerilogModule *>(shadow);
	  module->fragments.push_back(str);
	}		  
	std::string getName() const;
	void emit_fragments(std::ostream& os) const;
	VerilogSymbol getSymbol(std::string);
	void emit_header(std::ostream& os) const;
	void emit_footer(std::ostream& os) const;
	void emit_symbols(std::ostream& os) const;
	void emit_expressions(std::ostream& os) const;
	void emit(std::ostream&) const;
	void operator|(VerilogSymbol&);
	void operator<<(VerilogSymbol&);
	void operator>>(VerilogSymbol&);
};


#endif
